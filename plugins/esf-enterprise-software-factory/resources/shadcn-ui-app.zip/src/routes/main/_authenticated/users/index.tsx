import z from 'zod'
import { createFileRoute } from '@tanstack/react-router'
import { Users } from '@/apps/main/features/users'
import { roles } from '@/apps/main/features/users/data/data'

const usersSearchSchema = z.object({
  page: z.number().optional().catch(1),
  pageSize: z.number().optional().catch(10),
  status: z
    .array(
      z.union([
        z.literal('active'),
        z.literal('inactive'),
        z.literal('invited'),
        z.literal('suspended'),
      ])
    )
    .optional()
    .catch([]),
  role: z
    .array(z.enum(roles.map((r) => r.value as (typeof roles)[number]['value'])))
    .optional()
    .catch([]),
  username: z.string().optional().catch(''),
})

export const Route = createFileRoute('/main/_authenticated/users/')({
  validateSearch: usersSearchSchema,
  component: Users,
})
